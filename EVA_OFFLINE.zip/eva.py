import datetime
import json
import os

def carregar_dados():
    with open("dados_eva.json", "r", encoding="utf-8") as f:
        return json.load(f)

def salvar_historico(mensagem):
    with open("historico.txt", "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now()} - {mensagem}\n")

def registrar_feedback(frase):
    with open("feedback_eva.txt", "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now()} - {frase}\n")

def saudacao():
    agora = datetime.datetime.now()
    return f"Olá! Eu sou a Eva, sua assistente da AZ Car Rental. Hoje é {agora.strftime('%A, %d de %B de %Y')}, {agora.strftime('%H:%M:%S')}. Em que posso te ajudar?"

def responder(pergunta, dados):
    pergunta = pergunta.lower()
    if "família" in pergunta or "filhos" in pergunta:
        return "Para viagens em família, recomendo uma SUV ou minivan. Posso listar as opções."
    elif "trabalho" in pergunta or "executivo" in pergunta:
        return "Para negócios, os sedãs confortáveis são ideais. Deseja ver alguns modelos?"
    elif "econômico" in pergunta or "barato" in pergunta:
        return "Temos modelos econômicos com ótimo consumo. Quer que eu liste?"
    elif "seguro" in pergunta:
        return "Todos os veículos incluem opção de seguro básico e completo. Deseja incluir o seguro total?"
    elif "melhore" in pergunta or "gostei" in pergunta:
        registrar_feedback(pergunta)
        return "Obrigada! Suas sugestões me ajudam a melhorar."
    else:
        return "Posso sugerir um modelo com base no tipo de viagem: família, trabalho, economia ou aventura. Qual o seu foco?"

def main():
    dados = carregar_dados()
    print(saudacao())
    while True:
        entrada = input("Você: ")
        if entrada.lower() in ["sair", "exit", "fechar"]:
            print("Eva: Até mais! Estarei por aqui quando precisar. 🚗")
            break
        resposta = responder(entrada, dados)
        print(f"Eva: {resposta}")
        salvar_historico(f"Usuário: {entrada}")
        salvar_historico(f"Eva: {resposta}")

if __name__ == "__main__":
    main()
