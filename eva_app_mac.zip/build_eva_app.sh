
#!/usr/bin/env bash

echo "🔍 Verificando Python 3..."
if ! command -v python3 &>/dev/null; then
  echo "❌ Python 3 não encontrado. Instale com: brew install python"
  exit 1
fi

echo "📦 Instalando py2app..."
pip3 install --user py2app

DIR="eva_app"
rm -rf "$DIR" && mkdir "$DIR"
cd "$DIR" || exit

echo "✏️ Criando eva_assistente.py..."
cat > eva_assistente.py << 'EOF'
{eva_script}
EOF

echo "✏️ Criando setup.py..."
cat > setup.py << 'EOF'
{setup_script}
EOF

echo "🏗️ Construindo o .app..."
python3 setup.py py2app

echo "✅ Pronto! Seu app está em dist/eva_assistente.app"
