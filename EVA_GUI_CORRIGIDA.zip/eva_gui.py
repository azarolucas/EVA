import tkinter as tk
from tkinter import messagebox, scrolledtext
import datetime
import json
import os

def carregar_dados():
    with open("dados_eva.json", "r", encoding="utf-8") as f:
        return json.load(f)

def salvar_historico(mensagem):
    with open("historico.txt", "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now()} - {mensagem}\n")

def registrar_feedback(frase):
    with open("feedback_eva.txt", "a", encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now()} - {frase}\n")

def responder(pergunta, dados):
    pergunta = pergunta.lower()
    if "família" in pergunta or "filhos" in pergunta:
        return "Para viagens em família, recomendo uma SUV ou minivan. Posso listar as opções."
    elif "trabalho" in pergunta or "executivo" in pergunta:
        return "Para negócios, os sedãs confortáveis são ideais. Deseja ver alguns modelos?"
    elif "econômico" in pergunta or "barato" in pergunta:
        return "Temos modelos econômicos com ótimo consumo. Quer que eu liste?"
    elif "seguro" in pergunta:
        return "Todos os veículos incluem opção de seguro básico e completo. Deseja incluir o seguro total?"
    elif "melhore" in pergunta or "gostei" in pergunta:
        registrar_feedback(pergunta)
        return "Obrigada! Suas sugestões me ajudam a melhorar."
    else:
        return "Posso sugerir um modelo com base no tipo de viagem: família, trabalho, economia ou aventura. Qual o seu foco?"

class EvaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Eva – Assistente da AZ Car Rental")
        self.dados = carregar_dados()

        self.chat_log = scrolledtext.ScrolledText(root, width=60, height=20, wrap=tk.WORD)
        self.chat_log.pack(padx=10, pady=10)

        self.entry = tk.Entry(root, width=50)
        self.entry.pack(padx=10, pady=(0,10))
        self.entry.bind("<Return>", self.enviar)

        self.saudacao()

    def saudacao(self):
        agora = datetime.datetime.now()
        data_hora = agora.strftime('%A, %d de %B de %Y às %H:%M:%S')
        msg = f"Olá! Eu sou a Eva, sua assistente da AZ Car Rental. Hoje é {data_hora}.\nEm que posso te ajudar?"
        self.chat_log.insert(tk.END, "Eva: " + msg + "\n")

    def enviar(self, event):
        pergunta = self.entry.get()
        self.entry.delete(0, tk.END)
        if pergunta.lower() in ["sair", "exit", "fechar"]:
            self.root.quit()
        else:
            resposta = responder(pergunta, self.dados)
            self.chat_log.insert(tk.END, f"Você: {pergunta}\n")
            self.chat_log.insert(tk.END, f"Eva: {resposta}\n")
            salvar_historico(f"Usuário: {pergunta}")
            salvar_historico(f"Eva: {resposta}")
            self.chat_log.yview(tk.END)

if __name__ == "__main__":
    root = tk.Tk()
    app = EvaApp(root)
    root.mainloop()
