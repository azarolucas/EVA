
#!/usr/bin/env bash

echo "🔍 Verificando Python 3..."
if ! command -v python3 &>/dev/null; then
  echo "❌ Python 3 não encontrado. Instale com: brew install python"
  exit 1
fi

echo "📦 Instalando py2app..."
pip3 install --user py2app

echo "🏗️ Construindo o .app..."
python3 setup.py py2app

echo "✅ Pronto! Seu app está em dist/eva_assistente.app"

echo "🚀 Abrindo o aplicativo..."
open dist/eva_assistente.app
