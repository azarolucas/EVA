
from setuptools import setup

APP = ['eva_assistente.py']
OPTIONS = {
    'argv_emulation': True,
    'packages': ['tkinter'],
    'iconfile': None
}

setup(
    app=APP,
    options={'py2app': OPTIONS},
    setup_requires=['py2app'],
)
