
import tkinter as tk
from tkinter import messagebox, scrolledtext
import datetime, json, os, re

def carregar_dados():
    return json.load(open("dados_eva.json","r",encoding="utf-8")) if os.path.exists("dados_eva.json") else {}

def salvar_historico(mens):
    with open("historico.txt","a",encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now()} - {mens}\n")

def registrar_feedback(frase):
    with open("feedback_eva.txt","a",encoding="utf-8") as f:
        f.write(f"{datetime.datetime.now()} - {frase}\n")

def responder(pergunta,_):
    p = pergunta.lower()
    for pat, resp in {
        r"\bfam[íi]lia\b|\bfilhos?\b": "Para viagens em família, recomendo SUV/minivan. Listar opções?",
        r"\btrabalho\b|\bexecutivo\b": "Para negócios, sedãs confortáveis são ideais. Ver modelos?",
        r"\becon[oô]mico\b|\bbarato\b": "Modelos econômicos com ótimo consumo. Quer lista?",
        r"\bseguro\b": "Inclui seguro básico/completo. Incluir seguro total?",
        r"\bmelhorei\b|\bgostei\b|\bsugest[aã]o\b": "Obrigada, suas sugestões me ajudam a melhorar."
    }.items():
        if re.search(pat, p):
            if "sugest" in pat or "gostei" in pat: registrar_feedback(p)
            return resp
    return "Posso sugerir um modelo: família, trabalho, economia ou aventura. Qual o foco?"

class EvaApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Eva – Assistente AZ Car Rental")
        self.chat = scrolledtext.ScrolledText(root, width=60, height=20, wrap=tk.WORD, font=("Arial",11))
        self.chat.pack(padx=10, pady=10)
        self.entry = tk.Entry(root, width=50, font=("Arial",11))
        self.entry.pack(padx=10, pady=(0,10))
        self.entry.bind("<Return>", self.enviar)
        tk.Button(root, text="Limpar Chat", command=self.limpar).pack(pady=(0,10))
        self.saudacao()

    def saudacao(self):
        agora = datetime.datetime.now()
        data = agora.strftime('%A, %d de %B de %Y %H:%M:%S')
        self.exibir("Eva", f"Olá! Sou Eva da AZ Car Rental.\nHoje é {data}.\nEm que posso ajudar?")

    def exibir(self, r, t):
        self.chat.insert(tk.END, f"{r}: {t}\n")
        self.chat.yview(tk.END)

    def enviar(self,event=None):
        msg = self.entry.get().strip()
        if not msg: return
        self.entry.delete(0,tk.END)
        if msg.lower() in ["sair","exit","fechar"]: self.root.quit()
        else:
            self.exibir("Você", msg)
            resp = responder(msg,None)
            self.exibir("Eva", resp)
            salvar_historico(f"Você: {msg}")
            salvar_historico(f"Eva: {resp}")

    def limpar(self):
        self.chat.delete("1.0", tk.END)
        self.saudacao()

if __name__=="__main__":
    root=tk.Tk()
    EvaApp(root)
    root.mainloop()
